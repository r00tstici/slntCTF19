Put your characters in this directory.
Edit data/select.def to add characters to the selection list.